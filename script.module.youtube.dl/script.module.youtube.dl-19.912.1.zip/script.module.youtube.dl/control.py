# -*- coding: utf-8 -*-
from lib import main

main.main()
